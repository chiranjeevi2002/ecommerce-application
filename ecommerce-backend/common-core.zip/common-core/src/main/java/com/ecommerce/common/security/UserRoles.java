package com.ecommerce.common.security;

import java.util.Set;

import static com.ecommerce.common.security.Role.*;

public final class UserRoles {

    private UserRoles() {}
    
    public static final String DEFAULT = CUSTOMER.authority();

    public static final Set<String> ADMIN_ACCESS =
            Role.authorities(
                    ADMIN,
                    SUPERADMIN,
                    STORE_MANAGER
            );

    public static final Set<String> USER_ACCESS =
            Role.authorities(
                    CUSTOMER,
                    ADMIN,
                    SUPERADMIN
            );

    public static final Set<String> SUPERADMIN_ONLY = Role.authorities(SUPERADMIN);
    
    
    
    
    
}
